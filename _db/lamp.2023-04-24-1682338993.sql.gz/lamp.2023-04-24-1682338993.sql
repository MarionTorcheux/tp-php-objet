-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: lamp
-- ------------------------------------------------------
-- Server version	5.7.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES UTF8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `equipements`
--

DROP TABLE IF EXISTS `equipements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipements`
--

LOCK TABLES `equipements` WRITE;
/*!40000 ALTER TABLE `equipements` DISABLE KEYS */;
INSERT INTO `equipements` VALUES (1,'Grille-pain'),(2,'Machine à laver'),(3,'Machine à café'),(4,'Lave vaisselle'),(5,'Télé'),(6,'Wifi'),(7,'Bouilloire'),(8,'Sèche cheveux'),(9,'Plaques de cuisson'),(10,'Table'),(11,'Canapé'),(12,'Bureau');
/*!40000 ALTER TABLE `equipements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logement_equipement`
--

DROP TABLE IF EXISTS `logement_equipement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logement_equipement` (
  `logement_id` int(10) NOT NULL,
  `equipement_id` int(10) NOT NULL,
  PRIMARY KEY (`logement_id`,`equipement_id`),
  KEY `equipement_id` (`equipement_id`),
  CONSTRAINT `logement_equipement_ibfk_1` FOREIGN KEY (`logement_id`) REFERENCES `logements` (`id`),
  CONSTRAINT `logement_equipement_ibfk_2` FOREIGN KEY (`equipement_id`) REFERENCES `equipements` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logement_equipement`
--

LOCK TABLES `logement_equipement` WRITE;
/*!40000 ALTER TABLE `logement_equipement` DISABLE KEYS */;
INSERT INTO `logement_equipement` VALUES (2,1),(1,3),(1,5),(2,6),(3,6),(2,7),(3,7),(3,8),(2,9),(3,9),(1,10),(1,12);
/*!40000 ALTER TABLE `logement_equipement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logements`
--

DROP TABLE IF EXISTS `logements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pays` varchar(50) DEFAULT NULL,
  `adresse` varchar(100) DEFAULT NULL,
  `ville` varchar(60) DEFAULT NULL,
  `prix` int(10) DEFAULT NULL,
  `surface` varchar(10) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `couchage` int(2) DEFAULT NULL,
  `photo` varchar(50) DEFAULT NULL,
  `annonceur_id` int(10) DEFAULT NULL,
  `type_logement_id` int(10) DEFAULT NULL,
  `titre` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `annonceur_id` (`annonceur_id`),
  KEY `type_logement_id` (`type_logement_id`),
  CONSTRAINT `logements_ibfk_1` FOREIGN KEY (`annonceur_id`) REFERENCES `users` (`id`),
  CONSTRAINT `logements_ibfk_2` FOREIGN KEY (`type_logement_id`) REFERENCES `types_logement` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logements`
--

LOCK TABLES `logements` WRITE;
/*!40000 ALTER TABLE `logements` DISABLE KEYS */;
INSERT INTO `logements` VALUES (1,'France','17 rue des lilas','Paris',120,'50','Ma chambre c\'est la plus cool mais elle est partagée',1,'img/chambres/1.jpg',1,3,'Belle chambre'),(2,'Allemagne','20 avenue d\'Europe','Berlin',150,'60','Je loues ma grande chambre',2,'img/chambres/2.jpg',4,2,'Grande chambre'),(3,'France','67 Boulevard des apparts','Metz',20,'25','Petite chambre cosy pour faire une pause',4,'img/chambres/3.jpg',1,2,'Chambre cosy'),(4,'France','10 rue des pietons','Angouleme',70,'100','Petit coin de paradis',6,'img/chambres/8.jpg',1,1,'Petit coin de paradis'),(5,'France','20 rue des tests','Perpignan',50,'20','J\'aime la gym',2,'img/chambres/4.jpg',1,3,'Pouet Pouet'),(6,'France','19 av du pont','Perpignan',10,'50','Voici un test pour l\'ajout d\'un nouveau logement',6,'img/chambres/5.jpg',1,1,'Test'),(7,'France','45 avenue kouk','Perpignan',25,'50','un autre test',8,'img/chambres/6.jpg',1,1,'Mon nouveau logement');
/*!40000 ALTER TABLE `logements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservations`
--

DROP TABLE IF EXISTS `reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `logement_id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `date_debut` date DEFAULT NULL,
  `date_fin` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `logement_id` (`logement_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`logement_id`) REFERENCES `logements` (`id`),
  CONSTRAINT `reservations_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservations`
--

LOCK TABLES `reservations` WRITE;
/*!40000 ALTER TABLE `reservations` DISABLE KEYS */;
INSERT INTO `reservations` VALUES (1,4,2,'2023-12-24','2025-01-05'),(2,2,2,'2023-05-10','2023-05-12'),(3,1,3,'2023-07-04','2023-07-06'),(4,3,3,'2023-08-02','2023-08-05');
/*!40000 ALTER TABLE `reservations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `types_logement`
--

DROP TABLE IF EXISTS `types_logement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `types_logement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `types_logement`
--

LOCK TABLES `types_logement` WRITE;
/*!40000 ALTER TABLE `types_logement` DISABLE KEYS */;
INSERT INTO `types_logement` VALUES (1,'Logement entier'),(2,'Chambre privée'),(3,'Chambre partagée');
/*!40000 ALTER TABLE `types_logement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) DEFAULT NULL,
  `prenom` varchar(100) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `role_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Lafripouille','Cyrielle','f@gmail.com','12345',1),(2,'Limitatrice','Marion','marion@gmail.com','456789',2),(3,'Hallyday','JeanMarcel','jm@gmail.com','456123',2),(4,'Delafontaine','Jean','jean@gmail.com','9999',1),(5,'Cena','John','jc@gmail.com','c36d5e722dbc6366e5ef075f4439568f9fb68559dcbd2efb04a73c3603661156a396a628fe98d3998095c7a4929034fae3985bbaba4fe5c943a937a132648740',1),(6,'Pipo','Babar','pb@gmail.com','784b7aae6d9affe0ac801f6c6e4ba17ec95ba5c5d995b0180c6714bc6138a3a5b1bcf9b67ea1d79608f151a964d57356260e12df3516cb20a3828a239672efc3',2),(7,'Pouet','John','jp@gmail.com','a8ec9372dfff985efbcbdade6b6a6eed326d705ead2803f2a7770c8d090ee9b5ec5b6d2906dd8333ffe3cb2b3069e670dac03900e34b86434ec1306e804ed34c',1),(8,'Pan','Peter','pp@gmail.com','e613bdfe06e723269668c6de69f2ffa745cfe9bc43694454eeb5a92dfcaeb8ea6d9528f733738f7cea8222b2124b3aaca2ae0aacf98b83c92f0c09c4ddd9bd17',2),(9,'DeLaJungle','Baloo','b@gmail.com','594b0e3f24a49dcb34b699f0d8a8b3f3d7e2361e638eaeb3a761de3c5283689d8ffee9dacac4fe740e0e6d989a11d3297f322b203e496aec98f1be897cec9d8e',1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-24 12:23:13
